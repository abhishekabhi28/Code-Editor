// CodeEditor.js

import React, { useState } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { prism } from 'react-syntax-highlighter/dist/esm/styles/prism'; // or another prism theme

const CodeEditor = () => {
  const [code, setCode] = useState(`const greeting = 'Hello, world!';`);

  const handleChange = (e) => {
    setCode(e.target.value);
  };

  return (
    <div>
      <textarea
        value={code}
        onChange={handleChange}
        style={{
          width: '100%',
          height: '300px',
          fontFamily: '"Fira code", "Fira Mono", monospace',
          fontSize: 16,
        }}
      />
      <div style={{ marginTop: 10 }}>
        <SyntaxHighlighter language="javascript" style={prism}>
          {code}
        </SyntaxHighlighter>
      </div>
    </div>
  );
};

export default CodeEditor;
